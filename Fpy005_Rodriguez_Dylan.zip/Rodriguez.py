
import msvcrt
import random
import csv
import os
import time
trabajadores = ['Juan Pérez','María García','Carlos López','Ana Martínez','Pedro Rodríguez','Laura Hernández','Miguel Sánchez','Isabel Gómez','Francisco Díaz','Elena Fernández']

def sueldos_aleatorios():
    global sueldos
    sueldos={trabajador: random.randint(300000, 2500000) for trabajador in trabajadores}

    print("Sueldos agregados correctamente.")
    time.sleep(1)
    os.system('cls')
    
def clasificar_sueldos():
    menor_a_800k=[]
    entre_800_2m=[]
    mayor_a_2m=[]
    for trabajador, sueldo in sueldos.items():
        total_sueldos=sueldo*10
        if sueldo <= 800000:
            menor_a_800k.append((trabajador,sueldo))
        elif 800.000 <= sueldo <= 2000000:
            entre_800_2m.append((trabajador,sueldo))
        else:
            mayor_a_2m.append((trabajador,sueldo))
    print("Sueldos menores a 800.000:")
    for trabajador, sueldo in menor_a_800k:
        print(f"{trabajador}:${sueldo}")

    print(f"TOTAL: {len(menor_a_800k)}")
    time.sleep(0.7)
    
    print("Sueldos entre 800.000 y 2.000.000:")
    for trabajador, sueldo in entre_800_2m:
        print(f"{trabajador}:${sueldo}")

    print(f"Total: {len(entre_800_2m)}")
    time.sleep(0.7)

    print("Sueldos superiores a 2.000.000:")
    for trabajador,sueldo in mayor_a_2m:
        print(f"{trabajador}:${sueldo}")

    print(f"TOTAL: {len(mayor_a_2m)}")
    time.sleep(0.7)

    print(f"TOTAL SUELDOS:{total_sueldos}")
def ver_estadisticas():
    global sueldos
    if not sueldos:
        print("No hay sueldos registrados, reintente.")
        return
    lista_de_sueldos=list(sueldos.values())
    mayorsueldo=max(sueldos)
    menorsueldo=min(sueldos)
    promediosueldos=sum(lista_de_sueldos) / len(lista_de_sueldos)
    print(f"""
          Sueldo mas alto: {mayorsueldo}
          Sueldo mas bajo: {menorsueldo}
          Promedio de sueldos: {promediosueldos}
          """)
    time.sleep(3)
    os.system('cls')


def reporte_Sueldos_csv():
    with open('reporte_sueldos.csv', 'w', newline='') as f:
        writer=csv.writer(f)
        writer.writerow([' Nombre empleado ', ' Sueldo Base ', ' Descuento Salud ', ' Descuento AFP ', ' Sueldo Liquido '])
        for trabajador, sueldo in sueldos.items():
            descuentoS=sueldo * 0.07
            descuentoA=sueldo * 0.12
            Sliquido= sueldo - descuentoS - descuentoA
            writer.writerow([trabajador, f"${sueldo}",f"{descuentoS:.2f}",f"{descuentoA:.2f}",f"{Sliquido:.2f}"])
    print("Reporte de sueldos creado correctamente.")
def menu():
  while True:  
        opcion=input(""" 
            Seleccione una opcion:
            1.Asignar sueldos aleatorios.
            2.Clasificar Sueldos.
            3.Ver estadistias.
            4.Reporte de sueldos.
            5.Salir del programa.
                    
            opcion: """)
        
        if opcion == '1':
            sueldos_aleatorios()
        elif opcion == '2':
            clasificar_sueldos()
        elif opcion == '3':
            ver_estadisticas()
        elif opcion == '4': 
            reporte_Sueldos_csv()
        elif opcion == '5': 
            print("Finalizando programa...")
            print("Desarrollado por Dylan Rodriguez ")
            print("RUT: 20785317-8")
            break
        else: 
            print("POR FAVOR SELECCIONE UNA OPCION VALIDA. PARA CONTINUAR PRESIONE UNA TECLA.")
            msvcrt.getch()
if __name__=="__main__":
    menu()